# Be sure to restart your server when you modify this file.

Sx::Application.config.session_store :cookie_store, key: '_sx_session'
