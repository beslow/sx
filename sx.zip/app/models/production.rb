class Production < ActiveRecord::Base
end
