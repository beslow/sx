require 'test_helper'

class RegisterHelperTest < ActionView::TestCase
end
