require 'test_helper'

class LoginHelperTest < ActionView::TestCase
end
