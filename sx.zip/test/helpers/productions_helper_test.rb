require 'test_helper'

class ProductionsHelperTest < ActionView::TestCase
end
